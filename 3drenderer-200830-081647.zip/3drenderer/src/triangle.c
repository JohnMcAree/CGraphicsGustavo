#include "triangle.h"

// TODO: Create implementation for triangle.h functions
