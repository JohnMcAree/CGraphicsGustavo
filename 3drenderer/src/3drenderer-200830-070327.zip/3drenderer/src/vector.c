#include "vector.h"

// TODO: Implementation of all vector functions
